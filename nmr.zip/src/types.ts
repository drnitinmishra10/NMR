/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface HTMLPage {
  id: string;
  title: string;
  author: string;
  date: string;
  year: number;
  category: string;
  excerpt: string;
  citations: number;
  filePath: string;
  status: 'Active' | 'Draft' | 'Needs Review' | 'Orphaned';
  fileSize: string;
  lastModified: string;
  metaDescription: string;
  metaKeywords: string[];
  htmlContent?: string; // Embedded HTML content template
}

export interface TeamMember {
  name: string;
  role: string;
  avatar: string;
  bio?: string;
  email?: string;
}

export interface FocusArea {
  name: string;
  count: number;
}

export interface SiteStatistic {
  label: string;
  value: number;
  subLabel: string;
  icon: string;
}

export interface LinkAuditResult {
  sourceId: string;
  sourceTitle: string;
  targetPath: string;
  isValid: boolean;
  type: 'internal' | 'external';
}

export interface AuditReport {
  timestamp: string;
  scannedCount: number;
  brokenLinksCount: number;
  duplicateTitlesCount: number;
  duplicatePathsCount: number;
  missingMetaCount: number;
  brokenLinksList: { pageTitle: string; path: string; error: string }[];
  duplicateTitlesList: { title: string; count: number }[];
  missingMetaList: { pageTitle: string; missingFields: string[] }[];
}
