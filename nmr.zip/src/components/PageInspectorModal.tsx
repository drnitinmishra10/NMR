/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HTMLPage } from '../types';
import { 
  FileCode, Eye, Copy, Check, FileText, Info, Award, Calendar, Link, Tag, Compass 
} from 'lucide-react';

interface InspectorProps {
  page: HTMLPage | null;
  onClose: () => void;
}

export default function PageInspectorModal({ page, onClose }: InspectorProps) {
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>('preview');
  const [isCopied, setIsCopied] = useState(false);

  if (!page) return null;

  const handleCopyCode = () => {
    const code = page.htmlContent || `<!DOCTYPE html>\n<html>\n<head>\n  <title>${page.title}</title>\n</head>\n<body>\n  <h1>${page.title}</h1>\n</body>\n</html>`;
    navigator.clipboard.writeText(code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const getDocCode = () => {
    return page.htmlContent || `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.5">
  <meta name="description" content="${page.metaDescription}">
  <title>${page.title} | Mishra Lab</title>
</head>
<body style="font-family: sans-serif; padding: 2.5rem; color: #1e293b;">
  <article style="max-width: 800px; margin: 0 auto;">
    <span style="color: #4f46e5; font-size: 0.8rem; text-transform: uppercase;">${page.category}</span>
    <h1 style="font-size: 2.2rem; margin: 0.5rem 0 1rem 0;">${page.title}</h1>
    <p><strong>Published Date:</strong> ${page.date} by <strong>${page.author}</strong></p>
    <hr>
    <div>
      <p style="font-size: 1.1rem; line-height: 1.6;">${page.excerpt}</p>
    </div>
  </article>
</body>
</html>`;
  };

  return (
    <div className="fixed inset-0 bg-[#040e1f]/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#111c2d] border border-[#1f2a3c] w-full max-w-4xl rounded-xl overflow-hidden shadow-2xl flex flex-col h-[85vh] animate-scaleUp">
        
        {/* Header toolbar */}
        <div className="bg-[#152031] border-b border-[#1f2a3c] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 flex-shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className={`px-2 py-0.5 text-[9px] font-bold rounded-full font-sans uppercase ${
                page.status === 'Active' ? 'bg-green-950/40 text-green-300 border border-green-800' :
                page.status === 'Draft' ? 'bg-blue-950/40 text-blue-300 border border-blue-800' :
                page.status === 'Needs Review' ? 'bg-[#ffc640]/15 text-[#ffc640] border border-[#ffc640]/30' :
                'bg-red-950/40 text-red-300 border border-red-800'
              }`}>
                {page.status}
              </span>
              <span className="text-xs text-[#c6c6cd] font-mono flex items-center gap-1">
                <Link size={12} className="text-[#ffc640]" />
                {page.filePath}
              </span>
            </div>
            <h3 className="font-serif text-md md:text-lg font-bold text-[#d8e3fb] line-clamp-1">
              {page.title}
            </h3>
          </div>

          <button 
            onClick={onClose}
            className="text-[#c6c6cd] hover:text-[#ffc640] text-sm font-bold font-mono px-3 py-1 bg-[#0f172a] hover:bg-[#1f2a3c] rounded border border-[#1f2a3c] self-end sm:self-center"
          >
            ✕ Close View
          </button>
        </div>

        {/* Info stats strip */}
        <div className="bg-[#0f172a] border-b border-[#1f2a3c] px-6 py-3 flex flex-wrap gap-4 items-center text-xs text-[#c6c6cd] flex-shrink-0">
          <div className="flex items-center gap-1.5 border-r border-[#1f2a3c] pr-4">
            <Calendar size={13} className="text-[#ffc640]" />
            Modified: <b>{new Date(page.date).toLocaleDateString()}</b>
          </div>
          <div className="flex items-center gap-1.5 border-r border-[#1f2a3c] pr-4">
            <Award size={13} className="text-[#ffc640]" />
            Cited by: <b>{page.citations} references</b>
          </div>
          <div className="flex items-center gap-1.5 border-r border-[#1f2a3c] pr-4">
            <Compass size={13} className="text-[#ffc640]" />
            Category: <b>{page.category}</b>
          </div>
          <div>
            Size: <b>{page.fileSize || "18.5 KB"}</b>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="bg-[#111c2d] px-6 border-b border-[#1f2a3c] flex justify-between items-center flex-shrink-0">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('preview')}
              className={`py-3 text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
                activeTab === 'preview' 
                  ? 'border-[#ffc640] text-[#ffc640] font-bold' 
                  : 'border-transparent text-[#c6c6cd] hover:text-[#d8e3fb]'
              }`}
            >
              <Eye size={14} />
              Rendered Page Preview
            </button>
            <button
              onClick={() => setActiveTab('code')}
              className={`py-3 text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
                activeTab === 'code' 
                  ? 'border-[#ffc640] text-[#ffc640] font-bold' 
                  : 'border-transparent text-[#c6c6cd] hover:text-[#d8e3fb]'
              }`}
            >
              <FileCode size={14} />
              Plain HTML Source View
            </button>
          </div>

          {activeTab === 'code' && (
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2.5 py-1 text-[11px] bg-[#152031] text-[#ffc640] hover:bg-[#1f2a3c] border border-[#1f2a3c] rounded transition-all active:scale-95 cursor-pointer font-sans"
            >
              {isCopied ? <Check size={11} className="text-green-400" /> : <Copy size={11} />}
              {isCopied ? 'Copied' : 'Copy HTML'}
            </button>
          )}
        </div>

        {/* Content Box (Grows) */}
        <div className="flex-1 overflow-auto bg-[#040e1f] p-6">
          {activeTab === 'preview' ? (
            /* Rendered Preview Mockup Frame */
            <div className="mx-auto max-w-3xl bg-white text-[#1e293b] p-8 md:p-12 rounded-lg shadow-inner min-h-[400px] border border-gray-300 select-text">
              <span className="text-[11px] font-sans font-bold text-indigo-600 block tracking-widest uppercase mb-1">
                {page.category}
              </span>
              <h2 className="text-3xl font-serif font-bold text-gray-900 leading-tight mb-4">
                {page.title}
              </h2>
              
              <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 mb-6 pb-4 border-b border-gray-200">
                <span>By: <b>{page.author}</b></span>
                <span>•</span>
                <span>Date Published: <b>{page.date}</b></span>
                <span>•</span>
                <span>Path: <code className="bg-gray-100 text-[#0f172a] px-1 py-0.5 rounded">{page.filePath}</code></span>
              </div>

              <div className="text-sm leading-relaxed text-gray-700 space-y-4 font-sans">
                <p className="text-base text-gray-800 leading-relaxed italic first-letter:text-3xl first-letter:font-bold first-letter:text-indigo-600 first-letter:mr-3 first-letter:float-left">
                  {page.excerpt}
                </p>
                
                <h4 className="text-md font-semibold text-gray-900 mt-6 mb-2">1. Abstract Overview & Methodology</h4>
                <p>
                  To anchor the experimental setups, we constructed a multi-agent model matching core requirements for decentralized execution. Standard communication logs were recorded and optimized to lower operational latency benchmarks from typical 240ms targets to sub-60ms speeds without dropping the overall security parameters of our validation enclaves.
                </p>
                <p>
                  Further calculations will resolve duplicate requests inside validation enclaves directly, enabling automatic self-healing channels that preserve strict Byzantine resilience parameters despite high numbers of concurrent malicious nodes.
                </p>

                <h4 className="text-md font-semibold text-gray-900 mt-6 mb-2">2. Archival Site Indexing Details</h4>
                <p>
                  This item is securely indexed inside Dr. Nitin Mishra's Research Laboratory digital library on target path <code className="bg-gray-100 px-1 text-xs rounded">{page.filePath}</code>. Future audits will inspect relative citation lists of other HTML elements.
                </p>
              </div>

              {/* Mapped metadata keywords tag badges inside preview */}
              <div className="mt-8 pt-4 border-t border-gray-100 flex flex-wrap gap-2">
                {page.metaKeywords.map((k, idx) => (
                  <span key={idx} className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded text-[11px]">
                    # {k.toLowerCase()}
                  </span>
                ))}
              </div>
            </div>
          ) : (
            /* HTML Code Editor View with simulated syntax coloring */
            <div className="font-mono text-[11px] text-[#bec6e0] leading-relaxed bg-[#0f172a] p-4 rounded-lg border border-[#1f2a3c] overflow-x-auto h-full relative selection:bg-[#ffc640]/25">
              <pre className="whitespace-pre overflow-x-auto">
                <code>
                  {getDocCode().split('\n').map((line, num) => (
                    <div key={num} className="flex hover:bg-[#152031]/50 p-0.5 rounded">
                      <span className="w-10 text-[#c6c6cd]/30 select-none text-right pr-4 font-mono">
                        {num + 1}
                      </span>
                      <span className="text-[#d8e3fb]">
                        {/* Simple tag styling representation */}
                        {line.split(/(<[^>]+>)/g).map((token, tIdx) => {
                          if (token.startsWith('<') && token.endsWith('>')) {
                            return <span key={tIdx} className="text-[#ffc640]/90">{token}</span>;
                          } else if (token.includes('content=') || token.includes('name=')) {
                            return <span key={tIdx} className="text-green-300">{token}</span>;
                          }
                          return token;
                        })}
                      </span>
                    </div>
                  ))}
                </code>
              </pre>
            </div>
          )}
        </div>

        {/* Footer info tag */}
        <div className="bg-[#152031] p-4 border-t border-[#1f2a3c] flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0 text-xs text-[#c6c6cd]">
          <span className="flex items-center gap-1.5">
            <Info size={14} className="text-[#ffc640]" />
            Archival Search Index target matches metadata standard schema logs.
          </span>
          <button
            onClick={onClose}
            className="w-full sm:w-auto bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 px-4 py-2 rounded-lg font-semibold transition-all shadow active:scale-95"
          >
            Done Inspecting
          </button>
        </div>

      </div>
    </div>
  );
}
