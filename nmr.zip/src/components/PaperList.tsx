/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HTMLPage } from '../types';
import { Search, FileText, Quote, Download, ExternalLink, Calendar, Award, Compass, Eye, Tag } from 'lucide-react';

interface PaperListProps {
  pages: HTMLPage[];
  onInspectPage: (page: HTMLPage) => void;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
}

export default function PaperList({
  pages,
  onInspectPage,
  activeCategory,
  setActiveCategory
}: PaperListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSort, setActiveSort] = useState<'recent' | 'cited'>('recent');
  const [selectedCitation, setSelectedCitation] = useState<HTMLPage | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  // Filter and sort pages
  const filteredPages = pages.filter(page => {
    // Category match
    if (activeCategory !== 'All' && page.category !== activeCategory) {
      return false;
    }
    // Search match
    const query = searchQuery.toLowerCase().trim();
    if (!query) return true;

    return (
      page.title.toLowerCase().includes(query) ||
      page.excerpt.toLowerCase().includes(query) ||
      page.author.toLowerCase().includes(query) ||
      page.metaKeywords.some(tag => tag.toLowerCase().includes(query)) ||
      page.filePath.toLowerCase().includes(query)
    );
  });

  // Sort
  const sortedPages = [...filteredPages].sort((a, b) => {
    if (activeSort === 'recent') {
      return b.date.localeCompare(a.date);
    } else {
      return b.citations - a.citations;
    }
  });

  const handleCopyCitation = (citation: string) => {
    navigator.clipboard.writeText(citation);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const getBibtex = (p: HTMLPage) => {
    const key = p.author.split(' ')[1]?.toLowerCase() + p.year + p.title.split(' ')[0].toLowerCase();
    return `@article{${key || 'mishra' + p.year},\n  author = {${p.author}},\n  title = {${p.title}},\n  journal = {Mishra Research Archives},\n  year = {${p.year}},\n  url = {${p.filePath}}\n}`;
  };

  const getAPA = (p: HTMLPage) => {
    return `${p.author} (${p.year}). ${p.title}. Mishra Research Repository, Article Index.`;
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters Strip */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-[#040e1f] p-4 rounded-xl border border-[#1f2a3c]">
        {/* Search Input bar */}
        <div className="relative w-full md:max-w-md">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#c6c6cd]">
            <Search size={18} />
          </span>
          <input
            className="w-full pl-10 pr-4 py-3 bg-[#111c2d] border border-[#1f2a3c] rounded-lg focus:ring-2 focus:ring-[#ffc640] focus:border-[#ffc640] transition-all text-sm text-[#d8e3fb] placeholder:text-[#c6c6cd]/50"
            placeholder="Search papers by title, author, keyword..."
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Tab & Sorting buttons */}
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
          <button
            onClick={() => setActiveSort('recent')}
            className={`px-4 py-2 font-medium text-xs rounded-full transition-all flex items-center gap-1 cursor-pointer select-none ${
              activeSort === 'recent'
                ? 'bg-[#ffc640] text-[#402d00] font-semibold'
                : 'text-[#c6c6cd] hover:bg-[#152031] hover:text-[#d8e3fb]'
            }`}
          >
            <Calendar size={14} />
            Recent
          </button>
          
          <button
            onClick={() => setActiveSort('cited')}
            className={`px-4 py-2 font-medium text-xs rounded-full transition-all flex items-center gap-1 cursor-pointer select-none ${
              activeSort === 'cited'
                ? 'bg-[#ffc640] text-[#402d00] font-semibold'
                : 'text-[#c6c6cd] hover:bg-[#152031] hover:text-[#d8e3fb]'
            }`}
          >
            <Award size={14} />
            Most Cited
          </button>

          {activeCategory !== 'All' && (
            <span className="text-xs text-[#c6c6cd] px-3 py-1.5 bg-[#1f2a3c] rounded-full border border-[#ffc640]/20 flex items-center gap-1">
              <Compass size={12} className="text-[#ffc640]" />
              {activeCategory}
            </span>
          )}
        </div>
      </div>

      {/* Main Papers List */}
      <div className="space-y-4" id="paper-list">
        {sortedPages.length === 0 ? (
          <div className="text-center p-12 bg-[#111c2d] rounded-xl border border-[#1f2a3c]">
            <p className="text-[#c6c6cd] mb-2 font-medium text-sm">No documents matched your search indicators.</p>
            <p className="text-xs text-[#c6c6cd]/60">Try choosing a different focus area or modifying keywords.</p>
            <button 
              onClick={() => { setSearchQuery(''); setActiveCategory('All'); }}
              className="mt-4 px-4 py-2 text-xs bg-[#152031] border border-[#1f2a3c] rounded-lg text-[#ffc640] hover:bg-[#1f2a3c] transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          sortedPages.map((page) => (
            <article 
              key={page.id}
              className="bg-[#111c2d] border border-[#1f2a3c] p-6 rounded-xl hover:bg-[#152031] transition-all group relative duration-200"
            >
              <div className="flex justify-between items-start mb-3 gap-2">
                <span className="px-2.5 py-0.5 bg-[#ffc640]/10 text-[#ffc640] rounded text-[10px] uppercase font-bold tracking-widest border border-[#ffc640]/30 font-mono">
                  {page.category}
                </span>
                <div className="flex items-center gap-3 text-xs text-[#c6c6cd] font-mono">
                  <span>{page.year}</span>
                  {page.status !== 'Active' && (
                    <span className={`px-2 py-0.2 rounded text-[9px] uppercase font-bold ${
                      page.status === 'Draft' ? 'bg-blue-900/40 text-blue-300 border border-blue-800' :
                      page.status === 'Needs Review' ? 'bg-[#ffc640]/20 text-[#ffc640] border border-[#ffc640]/30' :
                      'bg-red-900/40 text-red-300 border border-red-800'
                    }`}>
                      {page.status}
                    </span>
                  )}
                </div>
              </div>

              <h3 className="font-serif text-lg md:text-xl text-[#d8e3fb] mb-3 group-hover:text-[#ffc640] transition-colors font-semibold leading-snug">
                {page.title}
              </h3>

              <p className="text-xs text-[#ffc640]/80 font-sans mb-3 font-medium">
                Authors: {page.author}
              </p>

              <p className="font-sans text-xs md:text-sm text-[#c6c6cd] mb-5 leading-relaxed">
                {page.excerpt}
              </p>

              {/* Keywords Tag pill map */}
              <div className="flex flex-wrap gap-2 mb-6">
                {page.metaKeywords.map((tag, idx) => (
                  <span 
                    key={idx}
                    onClick={() => setSearchQuery(tag)} 
                    className="text-[10px] bg-[#152031] text-[#c6c6cd] px-2 py-1 rounded border border-[#1f2a3c] hover:border-[#ffc640]/40 cursor-pointer transition-colors"
                  >
                    #{tag.toLowerCase()}
                  </span>
                ))}
              </div>

              {/* Bottom interactive items */}
              <div className="flex flex-wrap items-center gap-3 border-t border-[#1f2a3c] pt-4 justify-between">
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => onInspectPage(page)}
                    className="flex items-center gap-2 bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 px-4 py-2 rounded font-sans text-xs font-semibold transition-all select-none active:scale-95"
                  >
                    <Eye size={13} /> View Full Paper / Code
                  </button>
                  
                  <button
                    onClick={() => setSelectedCitation(page)}
                    className="flex items-center gap-1.5 border border-[#ffc640]/40 text-[#ffc640] hover:bg-[#ffc640]/10 px-3.5 py-2 rounded font-sans text-xs font-semibold transition-all select-none"
                  >
                    <Quote size={13} /> Cite
                  </button>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono text-[#c6c6cd] mt-2 md:mt-0">
                  <span className="flex items-center gap-1">
                    <Award size={14} className="text-[#ffc640]" />
                    <b>{page.citations}</b> citations
                  </span>
                  <span className="text-[10px]">
                    Size: <b>{page.fileSize}</b>
                  </span>
                </div>
              </div>
            </article>
          ))
        )}
      </div>

      {/* Citation Generator Dialog Modal Box */}
      {selectedCitation && (
        <div className="fixed inset-0 bg-[#040e1f]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111c2d] border border-[#1f2a3c] w-full max-w-lg rounded-xl overflow-hidden shadow-2xl animate-scaleUp">
            <div className="bg-[#152031] border-b border-[#1f2a3c] p-4 flex justify-between items-center">
              <h3 className="font-serif text-md font-bold text-[#d8e3fb] flex items-center gap-2">
                <Quote className="text-[#ffc640]" size={18} />
                Generate Bibliographic Citation
              </h3>
              <button 
                onClick={() => { setSelectedCitation(null); setCopiedText(false); }}
                className="text-[#c6c6cd] hover:text-[#ffc640] text-sm font-bold font-mono px-2 py-1 hover:bg-[#1f2a3c] rounded"
              >
                ✕
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <p className="text-xs text-[#c6c6cd]">
                Select and copy the citation standard in your preferred formatting standard.
              </p>

              {/* Standard APA Block */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[11px] font-mono uppercase text-[#ffc640]">
                  <span>APA (7th Edition)</span>
                  <button 
                    onClick={() => handleCopyCitation(getAPA(selectedCitation))}
                    className="text-xs text-[#d8e3fb] hover:underline"
                  >
                    Copy APA
                  </button>
                </div>
                <div className="bg-[#0f172a] p-3 rounded border border-[#1f2a3c] text-xs font-mono text-[#d8e3fb] select-all leading-relaxed">
                  {getAPA(selectedCitation)}
                </div>
              </div>

              {/* Standard Bibtex Block */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[11px] font-mono uppercase text-[#ffc640]">
                  <span>BibTeX format</span>
                  <button 
                    onClick={() => handleCopyCitation(getBibtex(selectedCitation))}
                    className="text-xs text-[#d8e3fb] hover:underline"
                  >
                    Copy BibTeX
                  </button>
                </div>
                <pre className="bg-[#0f172a] p-3 rounded border border-[#1f2a3c] text-[11px] font-mono text-[#d8e3fb] select-all overflow-x-auto whitespace-pre-wrap leading-relaxed">
                  {getBibtex(selectedCitation)}
                </pre>
              </div>

              {copiedText && (
                <div className="text-center p-1 bg-green-900/35 border border-green-700 rounded text-xs text-green-300 font-mono animate-fadeIn">
                  Citation copied to clipboard successfully!
                </div>
              )}
            </div>

            <div className="bg-[#152031] p-4 border-t border-[#1f2a3c] flex justify-end">
              <button
                onClick={() => { setSelectedCitation(null); setCopiedText(false); }}
                className="bg-[#0f172a] text-[#c6c6cd] border border-[#1f2a3c] hover:border-[#ffc640]/50 hover:text-[#ffc640] px-4 py-2 rounded text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
