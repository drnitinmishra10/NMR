/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Database, Search, Library, Users, Award, ShieldAlert, BookOpen, Menu, X } from 'lucide-react';

interface HeaderProps {
  currentView: 'public' | 'manager';
  setCurrentView: (view: 'public' | 'manager') => void;
  onOpenAudit: () => void;
  statsCount: {
    active: number;
    draft: number;
    needsReview: number;
    orphaned: number;
  };
}

export default function RepositoryHeader({
  currentView,
  setCurrentView,
  onOpenAudit,
  statsCount
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-[#040e1f] border-b border-[#1f2a3c] shadow-md h-16 md:h-20 transition-all">
      <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        {/* Brand Logo */}
        <div 
          onClick={() => {
            setCurrentView('public');
            setMobileMenuOpen(false);
          }}
          className="flex items-center gap-3 cursor-pointer group"
          id="logo-brand"
        >
          <div className="w-10 h-10 rounded-lg bg-[#111c2d] border border-[#1f2a3c] flex items-center justify-center text-[#ffc640] group-hover:border-[#ffc640] transition-colors">
            <Library size={22} className="text-[#ffc640]" />
          </div>
          <div>
            <span className="font-serif text-lg md:text-xl font-bold text-[#d8e3fb] tracking-tight group-hover:text-[#ffc640] transition-colors block">
              Mishra Research
            </span>
            <span className="text-[10px] font-sans text-[#c6c6cd] uppercase tracking-wider block -mt-1 font-medium">
              Repositoy Integrity & Indexer
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={() => setCurrentView('public')}
            className={`font-sans font-medium text-sm flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
              currentView === 'public'
                ? 'bg-[#152031] text-[#ffc640] border border-[#ffc640]/20'
                : 'text-[#c6c6cd] hover:text-[#d8e3fb] hover:bg-[#111c2d]'
            }`}
            id="nav-public"
          >
            <BookOpen size={16} />
            Publications Index
          </button>

          <button
            onClick={() => setCurrentView('manager')}
            className={`font-sans font-medium text-sm flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
              currentView === 'manager'
                ? 'bg-[#152031] text-[#ffc640] border border-[#ffc640]/20'
                : 'text-[#c6c6cd] hover:text-[#d8e3fb] hover:bg-[#111c2d]'
            }`}
            id="nav-manager"
          >
            <Database size={16} />
            HTML Site Manager
            {statsCount.needsReview + statsCount.orphaned > 0 && (
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse inline-block" />
            )}
          </button>

          {/* Quick Stats Summary badges in header */}
          <div className="flex items-center gap-2 px-3 py-1 bg-[#0f172a] rounded-full border border-[#1f2a3c] text-xs">
            <span className="text-[#c6c6cd]">Index Status:</span>
            <span className="font-bold text-green-400 font-mono">{statsCount.active} Ok</span>
            {statsCount.needsReview > 0 && (
              <span className="font-bold text-[#ffc640] font-mono">{statsCount.needsReview} Warn</span>
            )}
            {statsCount.orphaned > 0 && (
              <span className="font-bold text-red-400 font-mono">{statsCount.orphaned} Orphan</span>
            )}
          </div>
        </nav>

        {/* Desktop Admin Pill Actions */}
        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={onOpenAudit}
            className="flex items-center gap-2 bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 px-4 py-2 rounded-lg text-sm font-semibold transition-all shadow-md active:scale-95"
            id="btn-quick-audit"
          >
            <ShieldAlert size={16} />
            Site Integrity Scan
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-[#d8e3fb] hover:text-[#ffc640] p-2 hover:bg-[#152031] rounded-lg transition-colors"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#081425] border-b border-[#1f2a3c] animate-fadeIn">
          <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3">
            <button
              onClick={() => {
                setCurrentView('public');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left font-sans font-medium text-sm flex items-center gap-2 px-4 py-3 rounded-lg ${
                currentView === 'public'
                  ? 'bg-[#152031] text-[#ffc640]'
                  : 'text-[#c6c6cd] hover:bg-[#111c2d]'
              }`}
            >
              <BookOpen size={18} />
              Publications Index
            </button>

            <button
              onClick={() => {
                setCurrentView('manager');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left font-sans font-medium text-sm flex items-center gap-2 px-4 py-3 rounded-lg ${
                currentView === 'manager'
                  ? 'bg-[#152031] text-[#ffc640]'
                  : 'text-[#c6c6cd] hover:bg-[#111c2d]'
              }`}
            >
              <Database size={18} />
              HTML Site Manager
            </button>

            <button
              onClick={() => {
                onOpenAudit();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left font-sans font-medium text-sm flex items-center gap-2 px-4 py-3 rounded-lg text-[#ffc640] hover:bg-[#111c2d]"
            >
              <ShieldAlert size={18} />
              Site Integrity Scan
            </button>
          </div>
          <div className="border-t border-[#1f2a3c] pt-4 pb-4 px-4 flex justify-between text-xs text-[#c6c6cd]">
            <span>Active Indices: <b className="text-green-400">{statsCount.active}</b></span>
            <span>Needs Review: <b className="text-[#ffc640]">{statsCount.needsReview}</b></span>
            <span>Orphaned Docs: <b className="text-red-400">{statsCount.orphaned}</b></span>
          </div>
        </div>
      )}
    </header>
  );
}
