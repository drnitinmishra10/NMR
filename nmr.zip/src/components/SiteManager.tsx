/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HTMLPage, AuditReport } from '../types';
import { 
  Database, Search, Plus, Edit2, Trash2, ShieldCheck, CheckCircle2, AlertTriangle, 
  Eye, FileCode, Check, RefreshCw, AlertCircle, Info, ExternalLink, HelpCircle 
} from 'lucide-react';

interface SiteManagerProps {
  pages: HTMLPage[];
  onAddPage: (page: Omit<HTMLPage, 'id' | 'year' | 'lastModified' | 'fileSize'>) => void;
  onEditPage: (page: HTMLPage) => void;
  onDeletePage: (id: string) => void;
  onInspectPage: (page: HTMLPage) => void;
  auditReport: AuditReport | null;
  onRunAudit: () => void;
}

export default function SiteManager({
  pages,
  onAddPage,
  onEditPage,
  onDeletePage,
  onInspectPage,
  auditReport,
  onRunAudit
}: SiteManagerProps) {
  // Local UI filters
  const [managerSearch, setManagerSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  
  // Page creation form toggle & fields
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<HTMLPage | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    date: new Date().toISOString().split('T')[0],
    category: 'Distributed Systems',
    excerpt: '',
    citations: 0,
    filePath: '',
    status: 'Active' as const,
    metaDescription: '',
    metaKeywordsString: '',
    htmlContent: ''
  });

  const categories = ["Distributed Systems", "Machine Learning", "IoT Security", "AI Ethics"];

  // Handle form fields
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'citations' ? parseInt(value) || 0 : value
    }));
  };

  const resetForm = () => {
    setFormData({
      title: '',
      author: '',
      date: new Date().toISOString().split('T')[0],
      category: 'Distributed Systems',
      excerpt: '',
      citations: 0,
      filePath: '',
      status: 'Active' as const,
      metaDescription: '',
      metaKeywordsString: '',
      htmlContent: ''
    });
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.filePath) return alert('Title and File Path are required.');
    
    // Auto sanitise filePath leading slash
    let formattedPath = formData.filePath;
    if (!formattedPath.startsWith('/')) {
      formattedPath = '/' + formattedPath;
    }

    onAddPage({
      title: formData.title,
      author: formData.author || 'Dr. Nitin Mishra',
      date: formData.date,
      category: formData.category,
      excerpt: formData.excerpt,
      citations: formData.citations,
      filePath: formattedPath,
      status: formData.status,
      metaDescription: formData.metaDescription,
      metaKeywords: formData.metaKeywordsString ? formData.metaKeywordsString.split(',').map(tag => tag.trim()) : [],
      htmlContent: formData.htmlContent || `<!DOCTYPE html>\n<html>\n<head>\n  <meta charset="utf-8">\n  <title>${formData.title}</title>\n</head>\n<body>\n  <h1>${formData.title}</h1>\n</body>\n</html>`
    });

    setIsAdding(false);
    resetForm();
  };

  const handleEditClick = (page: HTMLPage) => {
    setIsEditing(page);
    setFormData({
      title: page.title,
      author: page.author,
      date: page.date,
      category: page.category,
      excerpt: page.excerpt,
      citations: page.citations,
      filePath: page.filePath,
      status: page.status,
      metaDescription: page.metaDescription,
      metaKeywordsString: page.metaKeywords.join(', '),
      htmlContent: page.htmlContent || ''
    });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEditing) return;

    onEditPage({
      ...isEditing,
      title: formData.title,
      author: formData.author,
      date: formData.date,
      category: formData.category,
      excerpt: formData.excerpt,
      citations: formData.citations,
      filePath: formData.filePath,
      status: formData.status,
      metaDescription: formData.metaDescription,
      metaKeywords: formData.metaKeywordsString ? formData.metaKeywordsString.split(',').map(tag => tag.trim()) : [],
      htmlContent: formData.htmlContent
    });

    setIsEditing(null);
    resetForm();
  };

  // Filter pages for view
  const queriedPages = pages.filter(page => {
    const term = managerSearch.toLowerCase();
    const matchesSearch = 
      page.title.toLowerCase().includes(term) ||
      page.filePath.toLowerCase().includes(term) ||
      page.author.toLowerCase().includes(term);

    const matchesStatus = statusFilter === 'All' || page.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getComplianceScore = () => {
    if (!auditReport) return 100;
    const deductions = (auditReport.brokenLinksCount * 15) + 
                       (auditReport.duplicatePathsCount * 25) + 
                       (auditReport.missingMetaCount * 5) + 
                       (auditReport.duplicateTitlesCount * 10);
    return Math.max(0, 100 - deductions);
  };

  return (
    <div className="space-y-6">
      {/* Search and Action Strip */}
      <div className="flex flex-col lg:flex-row gap-4 items-center justify-between bg-[#040e1f] p-4 rounded-xl border border-[#1f2a3c]">
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          <div className="relative w-full sm:w-64">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#c6c6cd]">
              <Search size={16} />
            </span>
            <input
              className="w-full pl-9 pr-4 py-2 bg-[#111c2d] border border-[#1f2a3c] rounded-lg focus:ring-1 focus:ring-[#ffc640] focus:border-[#ffc640] text-xs text-[#d8e3fb]"
              placeholder="Search file path or title..."
              type="text"
              value={managerSearch}
              onChange={(e) => setManagerSearch(e.target.value)}
            />
          </div>

          <select
            className="bg-[#111c2d] border border-[#1f2a3c] text-xs text-[#d8e3fb] rounded-lg px-3 py-2 cursor-pointer focus:ring-1 focus:ring-[#ffc640]"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="All">All Document Statuses</option>
            <option value="Active">Active</option>
            <option value="Draft">Draft</option>
            <option value="Needs Review">Needs Review</option>
            <option value="Orphaned">Orphaned Pages</option>
          </select>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <button
            onClick={() => { setIsAdding(true); resetForm(); }}
            className="flex items-center gap-1.5 bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 px-3.5 py-2 rounded-lg text-xs font-semibold shadow transition-all active:scale-95 cursor-pointer"
          >
            <Plus size={15} />
            Create HTML Index Page
          </button>
        </div>
      </div>

      {/* Main Panel Division Grid: Files Manifest (left) & Auditor Console (right) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Core Manifest Table (xl:col-span-8) */}
        <div className="xl:col-span-8 bg-[#111c2d] border border-[#1f2a3c] rounded-xl overflow-hidden shadow-sm">
          <div className="p-4 border-b border-[#1f2a3c] bg-[#152031] flex justify-between items-center">
            <h3 className="font-serif text-sm font-bold text-[#d8e3fb] flex items-center gap-2">
              <Database size={16} className="text-[#ffc640]" />
              Archived HTML Pages Index ({queriedPages.length} active queries)
            </h3>
            <span className="text-[10px] font-mono text-[#c6c6cd]">
              Double-click rows or click icons to manage templates
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#0f172a] text-[#c6c6cd] font-mono uppercase tracking-wider border-b border-[#1f2a3c]">
                  <th className="p-3">HTML Title & Target Target</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">File Attributes</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f2a3c]">
                {queriedPages.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-10 text-center text-[#c6c6cd]/50">
                      No files found matching filters. Create a new HTML template above!
                    </td>
                  </tr>
                ) : (
                  queriedPages.map((page) => (
                    <tr 
                      key={page.id}
                      className="hover:bg-[#152031]/80 transition-colors group cursor-pointer"
                    >
                      {/* Name & Target */}
                      <td className="p-3 max-w-xs">
                        <div className="font-sans font-semibold text-[#d8e3fb] group-hover:text-[#ffc640] transition-colors truncate">
                          {page.title}
                        </div>
                        <div className="font-mono text-[10px] text-[#c6c6cd]/60 mt-0.5 truncate flex items-center gap-1">
                          <FileCode size={11} className="text-[#ffc640]/50" />
                          {page.filePath}
                        </div>
                      </td>

                      {/* Category */}
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-[#0f172a] border border-[#1f2a3c] text-[#c6c6cd] rounded font-mono text-[9px]">
                          {page.category}
                        </span>
                      </td>

                      {/* File Attributes */}
                      <td className="p-3 font-mono text-[10px] text-[#c6c6cd]">
                        <div>Size: <b>{page.fileSize}</b></div>
                        <div className="text-[9px] text-[#c6c6cd]/60 mt-0.5">Refs: <b>{page.citations}</b> cites</div>
                      </td>

                      {/* Status */}
                      <td className="p-3">
                        <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-full font-sans ${
                          page.status === 'Active' ? 'bg-green-950/40 text-green-300 border border-green-800' :
                          page.status === 'Draft' ? 'bg-blue-950/40 text-blue-300 border border-blue-800' :
                          page.status === 'Needs Review' ? 'bg-[#ffc640]/15 text-[#ffc640] border border-[#ffc640]/30' :
                          'bg-red-950/40 text-red-300 border border-red-800'
                        }`}>
                          {page.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-right">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => onInspectPage(page)}
                            title="Interactive Preview"
                            className="p-1.5 hover:bg-[#1f2a3c] text-[#c6c6cd] hover:text-[#ffc640] rounded transition-all"
                          >
                            <Eye size={14} />
                          </button>
                          
                          <button
                            onClick={() => handleEditClick(page)}
                            title="Edit Meta Details"
                            className="p-1.5 hover:bg-[#1f2a3c] text-[#c6c6cd] hover:text-[#ffc640] rounded transition-all"
                          >
                            <Edit2 size={13} />
                          </button>

                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete ${page.title} from the static index?`)) {
                                onDeletePage(page.id);
                              }
                            }}
                            title="Delete file index"
                            className="p-1.5 hover:bg-red-950/30 text-[#c6c6cd] hover:text-red-400 rounded transition-all"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Site Auditor Side Console (xl:col-span-4) */}
        <div className="xl:col-span-4 space-y-6">
          <div className="bg-[#111c2d] border border-[#1f2a3c] p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-serif text-md font-bold text-[#d8e3fb] flex items-center gap-2">
                <ShieldCheck className="text-[#ffc640]" size={18} />
                Site Compliance Audit
              </h4>
              <button
                onClick={onRunAudit}
                className="p-1.5 bg-[#152031] text-[#ffc640] hover:bg-[#1f2a3c] rounded border border-[#1f2a3c] flex items-center justify-center transition-all cursor-pointer"
                title="Re-run compliance checks"
              >
                <RefreshCw size={13} />
              </button>
            </div>

            {auditReport ? (
              <div className="space-y-4">
                {/* Score Indicator */}
                <div className="bg-[#0f172a] p-4 rounded-lg border border-[#1f2a3c] text-center">
                  <div className="text-[10px] uppercase font-mono tracking-widest text-[#c6c6cd]/75 mb-1">
                    Index Compliance Score
                  </div>
                  <div className={`text-4xl font-serif font-bold ${
                    getComplianceScore() >= 90 ? 'text-green-400' :
                    getComplianceScore() >= 70 ? 'text-[#ffc640]' :
                    'text-red-400'
                  }`}>
                    {getComplianceScore()}%
                  </div>
                  <div className="text-[10px] text-[#c6c6cd] mt-2 leading-relaxed">
                    Based on directory checks, meta keywords coverage, and relative link audits.
                  </div>
                </div>

                {/* Stat breakdown box */}
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center py-1.5 border-b border-[#1f2a3c]">
                    <span className="text-[#c6c6cd]">Broken/Unresolvable Paths:</span>
                    <b className={`font-mono ${auditReport.brokenLinksCount > 0 ? 'text-red-400' : 'text-green-400'}`}>
                      {auditReport.brokenLinksCount} errors
                    </b>
                  </div>
                  <div className="flex justify-between items-center py-1.5 border-b border-[#1f2a3c]">
                    <span className="text-[#c6c6cd]">Duplicate Paths Reserved:</span>
                    <b className={`font-mono ${auditReport.duplicatePathsCount > 0 ? 'text-red-400' : 'text-green-400'}`}>
                      {auditReport.duplicatePathsCount} duplicates
                    </b>
                  </div>
                  <div className="flex justify-between items-center py-1.5 border-b border-[#1f2a3c]">
                    <span className="text-[#c6c6cd]">Missing Meta Tags/Desc:</span>
                    <b className={`font-mono ${auditReport.missingMetaCount > 0 ? 'text-[#ffc640]' : 'text-green-400'}`}>
                      {auditReport.missingMetaCount} alerts
                    </b>
                  </div>
                  <div className="flex justify-between items-center py-1.5">
                    <span className="text-[#c6c6cd]">Audit Date Timestamp:</span>
                    <span className="font-mono text-[9px] text-[#c6c6cd]/70">
                      {new Date(auditReport.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>

                {/* Audit Actions Warnings List */}
                <div className="space-y-2 mt-4 max-h-48 overflow-y-auto pr-1">
                  {auditReport.brokenLinksList.map((err, i) => (
                    <div key={i} className="flex gap-2 p-2 bg-red-950/20 border border-red-900/40 rounded text-[11px] text-red-300">
                      <AlertCircle size={14} className="flex-shrink-0 mt-0.5" />
                      <div>
                        <b>Broken Path:</b> <code>{err.path}</code> claimed in <i>{err.pageTitle}</i> is unresolvable or poorly formed.
                      </div>
                    </div>
                  ))}

                  {auditReport.missingMetaList.map((warn, i) => (
                    <div key={i} className="flex gap-2 p-2 bg-orange-950/25 border border-orange-900/40 rounded text-[11px] text-[#ffc640]">
                      <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" />
                      <div>
                        <b>Missing Meta:</b> <i>{warn.pageTitle}</i> is missing [{warn.missingFields.join(', ')}]. Highly discouraged for archival indexing.
                      </div>
                    </div>
                  ))}

                  {auditReport.brokenLinksCount === 0 && auditReport.missingMetaCount === 0 && (
                    <div className="flex items-center gap-2 p-3 bg-green-950/25 border border-green-800/40 rounded text-xs text-green-300">
                      <CheckCircle2 size={16} />
                      Zero warnings detected! Your local HTML indexes conform to ideal schema standards.
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-10 space-y-3">
                <Info size={28} className="mx-auto text-[#c6c6cd]/50" />
                <p className="text-xs text-[#c6c6cd]">
                  No compliance logs compiled. Perform a system index check to review directory structures.
                </p>
                <button
                  onClick={onRunAudit}
                  className="px-4 py-2 bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Inspect Directory Files
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Slide-over Form Overlay: CREATE PAGE / EDIT PAGE Modal Overlay */}
      {(isAdding || isEditing) && (
        <div className="fixed inset-0 bg-[#040e1f]/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111c2d] border border-[#1f2a3c] w-full max-w-2xl rounded-xl overflow-hidden shadow-2xl animate-scaleUp">
            
            {/* Modal Header */}
            <div className="bg-[#152031] border-b border-[#1f2a3c] p-4 flex justify-between items-center">
              <h3 className="font-serif text-md font-bold text-[#d8e3fb] flex items-center gap-1.5">
                <FileCode className="text-[#ffc640]" size={18} />
                {isAdding ? 'Register New HTML Archive' : `Modify Index Meta: ${isEditing?.title}`}
              </h3>
              <button 
                onClick={() => { setIsAdding(false); setIsEditing(null); resetForm(); }}
                className="text-[#c6c6cd] hover:text-[#ffc640] text-sm font-bold font-mono px-2 py-1"
              >
                ✕
              </button>
            </div>

            {/* Modal Body ScrollForm */}
            <form onSubmit={isAdding ? handleCreateSubmit : handleEditSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Form Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Title */}
                <div className="md:col-span-2 space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">HTML Document Title *</label>
                  <input
                    name="title"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb] focus:ring-1 focus:ring-[#ffc640] focus:border-[#ffc640]"
                    placeholder="e.g. Byzantine Consensus Protocols over Smart Cities grids"
                    type="text"
                    required
                    value={formData.title}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Authors */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Responsible Authors</label>
                  <input
                    name="author"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb] focus:ring-1 focus:ring-[#ffc640]"
                    placeholder="e.g. Dr. Nitin Mishra, Dr. Sarah Chen"
                    type="text"
                    value={formData.author}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Unique File Path */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Registry URI Path * (Must start with /)</label>
                  <input
                    name="filePath"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb] focus:ring-1 focus:ring-[#ffc640]"
                    placeholder="e.g. /papers/distributed/consensus-2024.html"
                    type="text"
                    required
                    disabled={!!isEditing}
                    value={formData.filePath}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Topic Area */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Category/Sector</label>
                  <select
                    name="category"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    value={formData.category}
                    onChange={handleInputChange}
                  >
                    {categories.map((cat, idx) => (
                      <option key={idx} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                {/* Status */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Registry Status</label>
                  <select
                    name="status"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="Active">Active Index</option>
                    <option value="Draft">Draft Outline</option>
                    <option value="Needs Review">Needs Review</option>
                    <option value="Orphaned">Orphaned Pages (Historical Archive)</option>
                  </select>
                </div>

                {/* Publication Date */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Publication Date</label>
                  <input
                    name="date"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    type="date"
                    value={formData.date}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Citation numbers */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Starting citations count</label>
                  <input
                    name="citations"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    type="number"
                    min="0"
                    value={formData.citations}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Meta Keywords */}
                <div className="md:col-span-2 space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">SEO Search keywords (separated by commas)</label>
                  <input
                    name="metaKeywordsString"
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    placeholder="consensus, blockchain, multi-agent, security"
                    type="text"
                    value={formData.metaKeywordsString}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Abstract Text block */}
                <div className="md:col-span-2 space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">Publication Abstract / Excerpt Prompt (Must describe pages)</label>
                  <textarea
                    name="excerpt"
                    rows={3}
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    placeholder="We propose a systematic approach to aggregate..."
                    value={formData.excerpt}
                    onChange={handleInputChange}
                  />
                </div>

                {/* SEO Description tag */}
                <div className="md:col-span-2 space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#c6c6cd]">SEO HTML &lt;meta name="description"&gt; tag</label>
                  <textarea
                    name="metaDescription"
                    rows={2}
                    className="w-full bg-[#0f172a] border border-[#1f2a3c] rounded p-2 text-xs text-[#d8e3fb]"
                    placeholder="A detailed study on Byzantine consensus protocols inside distributed high-traffic FinTech registries..."
                    value={formData.metaDescription}
                    onChange={handleInputChange}
                  />
                </div>

                {/* Embedded HTML source code */}
                <div className="md:col-span-2 space-y-1">
                  <label className="block text-[11px] font-mono uppercase text-[#ffc640]">Embedded Raw HTML File Template Source Code</label>
                  <textarea
                    name="htmlContent"
                    rows={6}
                    className="w-full bg-[#040e1f] border border-[#1f2a3c] rounded p-3 text-xs font-mono text-[#d8e3fb]"
                    placeholder="<!DOCTYPE html>&#10;<html>&#10;..."
                    value={formData.htmlContent}
                    onChange={handleInputChange}
                  />
                </div>

              </div>

              {/* Action cluster buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-[#1f2a3c]">
                <button
                  type="button"
                  onClick={() => { setIsAdding(false); setIsEditing(null); resetForm(); }}
                  className="bg-[#0f172a] text-[#c6c6cd] border border-[#1f2a3c] hover:bg-[#152031] px-4 py-2 rounded text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 px-4 py-2 rounded text-xs font-bold transition-all active:scale-95"
                >
                  {isAdding ? 'Register Page in Index' : 'Apply Changes'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}
    </div>
  );
}
