/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Award, FileCode, Landmark, GitBranch } from 'lucide-react';

interface StatsProps {
  totalPagesCount: number;
  totalCitations: number;
}

export default function StatsGrid({ totalPagesCount, totalCitations }: StatsProps) {
  // We mirror the starting state from Dr. Mishra's repository stats:
  // e.g. 25 Papers, 66 HTML Files, 440 Citations, 4 Active Projects.
  // When pages are modified, the numbers will transition dynamically.
  const [papers, setPapers] = useState(0);
  const [htmlFiles, setHtmlFiles] = useState(0);
  const [citations, setCitations] = useState(0);
  const [projects, setProjects] = useState(0);

  useEffect(() => {
    // Elegant transition of starting stats
    const timer = setTimeout(() => {
      setPapers(Math.max(25, totalPagesCount * 2));
      setHtmlFiles(Math.max(66, totalPagesCount * 4));
      setCitations(Math.max(440, totalCitations));
      setProjects(4);
    }, 150);

    return () => clearTimeout(timer);
  }, [totalPagesCount, totalCitations]);

  return (
    <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
      {/* Total Papers Category Detail */}
      <div 
        className="stats-card bg-[#111c2d] p-4 md:p-6 rounded-xl border border-[#1f2a3c] text-center hover:-translate-y-1 transition-all duration-300"
        id="stat-papers-card"
      >
        <div className="flex md:flex-row flex-col items-center justify-center gap-2 mb-2">
          <Award className="text-[#ffc640] w-5 h-5 md:w-6 md:h-6" />
          <span className="font-sans text-[11px] md:text-xs text-[#c6c6cd] uppercase tracking-wider font-semibold">
            Publications
          </span>
        </div>
        <div className="text-[#ffc640] font-serif text-3xl md:text-4xl font-bold tracking-tight mb-1" id="stat-papers">
          {papers}
        </div>
        <div className="text-[10px] text-[#c6c6cd] font-sans opacity-75">
          {totalPagesCount} Managed Document Indexes
        </div>
      </div>

      {/* HTML Files Counter */}
      <div 
        className="stats-card bg-[#111c2d] p-4 md:p-6 rounded-xl border border-[#1f2a3c] text-center hover:-translate-y-1 transition-all duration-300"
        id="stat-files-card"
      >
        <div className="flex md:flex-row flex-col items-center justify-center gap-2 mb-2">
          <FileCode className="text-[#ffc640] w-5 h-5 md:w-6 md:h-6" />
          <span className="font-sans text-[11px] md:text-xs text-[#c6c6cd] uppercase tracking-wider font-semibold">
            HTML Page Assets
          </span>
        </div>
        <div className="text-[#ffc640] font-serif text-3xl md:text-4xl font-bold tracking-tight mb-1" id="stat-files">
          {htmlFiles}
        </div>
        <div className="text-[10px] text-[#c6c6cd] font-sans opacity-75">
          Static file mapping templates
        </div>
      </div>

      {/* Citations Indicator */}
      <div 
        className="stats-card bg-[#111c2d] p-4 md:p-6 rounded-xl border border-[#1f2a3c] text-center hover:-translate-y-1 transition-all duration-300"
        id="stat-citations-card"
      >
        <div className="flex md:flex-row flex-col items-center justify-center gap-2 mb-2">
          <Landmark className="text-[#ffc640] w-5 h-5 md:w-6 md:h-6" />
          <span className="font-sans text-[11px] md:text-xs text-[#c6c6cd] uppercase tracking-wider font-semibold">
            Total Citations
          </span>
        </div>
        <div className="text-[#ffc640] font-serif text-3xl md:text-4xl font-bold tracking-tight mb-1" id="stat-citations">
          {citations}
        </div>
        <div className="text-[10px] text-[#c6c6cd] font-sans opacity-75">
          Verified academic references
        </div>
      </div>

      {/* Core Active Research Units */}
      <div 
        className="stats-card bg-[#111c2d] p-4 md:p-6 rounded-xl border border-[#1f2a3c] text-center hover:-translate-y-1 transition-all duration-300"
        id="stat-projects-card"
      >
        <div className="flex md:flex-row flex-col items-center justify-center gap-2 mb-2">
          <GitBranch className="text-[#ffc640] w-5 h-5 md:w-6 md:h-6" />
          <span className="font-sans text-[11px] md:text-xs text-[#c6c6cd] uppercase tracking-wider font-semibold">
            Active Projects
          </span>
        </div>
        <div className="text-[#ffc640] font-serif text-3xl md:text-4xl font-bold tracking-tight mb-1" id="stat-projects">
          {projects}
        </div>
        <div className="text-[10px] text-[#c6c6cd] font-sans opacity-75">
          Mishra Laboratory sectors
        </div>
      </div>
    </section>
  );
}
