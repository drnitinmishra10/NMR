/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { TeamMember, HTMLPage, FocusArea } from '../types';
import { Mail, GraduationCap, ArrowRight, Circle, Bookmark } from 'lucide-react';

interface SidebarProps {
  teamMembers: TeamMember[];
  pages: HTMLPage[];
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  onPreviewMember: (member: TeamMember) => void;
}

export default function TeamFocusSidebar({
  teamMembers,
  pages,
  activeCategory,
  setActiveCategory,
  onPreviewMember
}: SidebarProps) {
  // Aggregate dynamic focus area counts from our real managed HTML records
  const getDynamicCount = (category: string, baseOffset: number) => {
    const realCount = pages.filter(p => p.category === category).length;
    return realCount + baseOffset;
  };

  const focusAreasConfig = [
    { name: "Distributed Systems", baseOffset: 9 },
    { name: "Machine Learning", baseOffset: 20 },
    { name: "IoT Security", baseOffset: 6 },
    { name: "AI Ethics", baseOffset: 12 }
  ];

  return (
    <aside className="space-y-6">
      {/* Research Team Card */}
      <div className="bg-[#111c2d] p-6 rounded-xl border border-[#1f2a3c] shadow-sm">
        <h4 className="font-serif text-lg font-bold text-[#d8e3fb] mb-4 flex items-center gap-2">
          <GraduationCap className="text-[#ffc640]" size={20} />
          Research Team
        </h4>
        <div className="space-y-4">
          {teamMembers.map((member, index) => (
            <div 
              key={index}
              onClick={() => onPreviewMember(member)}
              className="flex items-center gap-4 group cursor-pointer p-2 hover:bg-[#152031] rounded-lg transition-all border border-transparent hover:border-[#1f2a3c]"
            >
              <div className="w-12 h-12 rounded-full overflow-hidden bg-[#0f172a] border border-[#1f2a3c] flex-shrink-0 group-hover:border-[#ffc640] transition-colors">
                <img 
                  className="w-full h-full object-cover" 
                  src={member.avatar} 
                  alt={member.name} 
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-sans font-semibold text-sm text-[#d8e3fb] group-hover:text-[#ffc640] transition-colors truncate">
                  {member.name}
                </div>
                <div className="text-[11px] font-sans text-[#c6c6cd] truncate">
                  {member.role}
                </div>
              </div>
              <ArrowRight size={14} className="text-[#c6c6cd] opacity-0 group-hover:opacity-100 transition-opacity -translate-x-2 group-hover:translate-x-0" />
            </div>
          ))}
        </div>
      </div>

      {/* Focus Areas Category Accordion Menu */}
      <div className="bg-[#111c2d] p-6 rounded-xl border border-[#1f2a3c] shadow-sm">
        <h4 className="font-serif text-lg font-bold text-[#d8e3fb] mb-4 flex items-center gap-2">
          <Bookmark className="text-[#ffc640]" size={18} />
          Focus Areas
        </h4>
        <div className="space-y-2">
          {focusAreasConfig.map((area, index) => {
            const displayCount = getDynamicCount(area.name, area.baseOffset);
            const isSelected = activeCategory === area.name;

            return (
              <button
                key={index}
                onClick={() => setActiveCategory(isSelected ? 'All' : area.name)}
                className={`w-full flex justify-between items-center text-left text-sm p-3 rounded-lg cursor-pointer transition-all border text-[#c6c6cd] ${
                  isSelected 
                    ? 'bg-[#152031] text-[#ffc640] border-[#ffc640]/40 font-semibold' 
                    : 'bg-transparent border-transparent hover:bg-[#152031] hover:text-[#d8e3fb]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${isSelected ? 'bg-[#ffc640]' : 'bg-[#1f2a3c]'}`} />
                  <span>{area.name}</span>
                </div>
                <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded-full ${
                  isSelected ? 'bg-[#ffc640] text-[#402d00]' : 'bg-[#152031] text-[#d8e3fb] border border-[#1f2a3c]'
                }`}>
                  {displayCount}
                </span>
              </button>
            );
          })}
          {activeCategory !== 'All' && (
            <button
              onClick={() => setActiveCategory('All')}
              className="w-full text-center text-xs text-[#ffc640] hover:underline mt-2 font-medium"
            >
              Clear Focus Filter
            </button>
          )}
        </div>
      </div>
    </aside>
  );
}
