/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HTMLPage, TeamMember, AuditReport } from './types';
import { INITIAL_PAGES, INITIAL_TEAM_MEMBERS } from './data';

import RepositoryHeader from './components/RepositoryHeader';
import StatsGrid from './components/StatsGrid';
import TeamFocusSidebar from './components/TeamFocusSidebar';
import PaperList from './components/PaperList';
import SiteManager from './components/SiteManager';
import PageInspectorModal from './components/PageInspectorModal';

import { 
  ShieldCheck, AlertTriangle, Cpu, Globe, Compass, GraduationCap, 
  Workflow, CheckCircle, ExternalLink, HelpCircle, Mail, Info 
} from 'lucide-react';

export default function App() {
  // Navigation & Core States
  const [currentView, setCurrentView] = useState<'public' | 'manager'>('public');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  
  // Database State - initialized from localStorage if existing, otherwise base mocks
  const [pages, setPages] = useState<HTMLPage[]>(() => {
    const saved = localStorage.getItem('mishra_repository_pages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (err) {
        console.error('Failed to parse localStorage pages, fallback to mock data', err);
      }
    }
    return INITIAL_PAGES;
  });

  // Persist pages
  useEffect(() => {
    localStorage.setItem('mishra_repository_pages', JSON.stringify(pages));
  }, [pages]);

  // Inspection states
  const [inspectedPage, setInspectedPage] = useState<HTMLPage | null>(null);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  // Site Compliance Integrity Audit state
  const [auditReport, setAuditReport] = useState<AuditReport | null>(null);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);

  // Link validation audit algorithm
  const executeSiteAudit = (currentPages: HTMLPage[]): AuditReport => {
    const brokenLinksList: { pageTitle: string; path: string; error: string }[] = [];
    const duplicateTitlesList: { title: string; count: number }[] = [];
    const missingMetaList: { pageTitle: string; missingFields: string[] }[] = [];
    
    const pathSet = new Set<string>();
    let duplicatePathsCount = 0;
    const titleCounts: Record<string, number> = {};

    currentPages.forEach(p => {
      // Check path uniqueness
      if (pathSet.has(p.filePath)) {
        duplicatePathsCount++;
      } else {
        pathSet.add(p.filePath);
      }

      // Check title duplicate counts
      titleCounts[p.title] = (titleCounts[p.title] || 0) + 1;

      // Check SEO and XML headers completeness
      const missing: string[] = [];
      if (!p.metaDescription || p.metaDescription.trim().length < 15) {
        missing.push('Description Meta Tag');
      }
      if (!p.metaKeywords || p.metaKeywords.length === 0) {
        missing.push('Keywords / Tags Index');
      }
      if (missing.length > 0) {
        missingMetaList.push({
          pageTitle: p.title,
          missingFields: missing
        });
      }

      // Scan content/abstract excerpts for references ending with '.html' to see if they exist
      const htmlRegex = /(\/[a-zA-Z0-9_\-\/]+\.html)/g;
      let match;
      while ((match = htmlRegex.exec(p.excerpt)) !== null) {
        const referencedPath = match[1];
        // Check if referencedPath sits anywhere inside the repository
        const targetExists = currentPages.some(page => page.filePath === referencedPath);
        if (!targetExists) {
          brokenLinksList.push({
            pageTitle: p.title,
            path: referencedPath,
            error: 'Path cited in abstract/excerpt resides outside manifest registry'
          });
        }
      }
    });

    // Collect title duplicates
    Object.entries(titleCounts).forEach(([title, count]) => {
      if (count > 1) {
        duplicateTitlesList.push({ title, count });
      }
    });

    return {
      timestamp: new Date().toISOString(),
      scannedCount: currentPages.length,
      brokenLinksCount: brokenLinksList.length,
      duplicateTitlesCount: duplicateTitlesList.length,
      duplicatePathsCount,
      missingMetaCount: missingMetaList.length,
      brokenLinksList,
      duplicateTitlesList,
      missingMetaList
    };
  };

  // Run audit on load and when pages directory changes
  useEffect(() => {
    const report = executeSiteAudit(pages);
    setAuditReport(report);
  }, [pages]);

  const handleRunAudit = () => {
    const report = executeSiteAudit(pages);
    setAuditReport(report);
  };

  // State stats variables
  const activeCount = pages.filter(p => p.status === 'Active').length;
  const draftCount = pages.filter(p => p.status === 'Draft').length;
  const needsReviewCount = pages.filter(p => p.status === 'Needs Review').length;
  const orphanedCount = pages.filter(p => p.status === 'Orphaned').length;

  const totalCitations = pages.reduce((acc, p) => acc + p.citations, 0);

  // Index manager actions
  const handleAddPage = (newPageData: Omit<HTMLPage, 'id' | 'year' | 'lastModified' | 'fileSize'>) => {
    const newPage: HTMLPage = {
      ...newPageData,
      id: `page-${Date.now()}`,
      year: new Date(newPageData.date).getFullYear() || new Date().getFullYear(),
      lastModified: new Date().toISOString(),
      fileSize: `${(Math.random() * 45 + 5).toFixed(1)} KB`
    };

    setPages(prev => [newPage, ...prev]);
  };

  const handleEditPage = (editedPage: HTMLPage) => {
    setPages(prev => prev.map(p => p.id === editedPage.id ? {
      ...editedPage,
      year: new Date(editedPage.date).getFullYear(),
      lastModified: new Date().toISOString()
    } : p));
  };

  const handleDeletePage = (id: string) => {
    setPages(prev => prev.filter(p => p.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#081425] text-[#d8e3fb] selection:bg-[#ffc640]/30 selection:text-[#081425]">
      
      {/* Header Toolbar */}
      <RepositoryHeader
        currentView={currentView}
        setCurrentView={setCurrentView}
        onOpenAudit={() => setIsAuditModalOpen(true)}
        statsCount={{
          active: activeCount,
          draft: draftCount,
          needsReview: needsReviewCount,
          orphaned: orphanedCount
        }}
      />

      {/* Main Container spacing wrapper */}
      <main className="max-w-7xl mx-auto pt-24 md:pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        
        {/* Academic branding Hero container - ONLY visible on public view or as an elegant header */}
        {currentView === 'public' && (
          <section className="mb-10 p-6 md:p-8 rounded-2xl bg-gradient-to-br from-[#111c2d] to-[#040e1f] border border-[#1f2a3c] shadow-lg relative overflow-hidden transition-all">
            <div className="absolute right-0 bottom-0 top-0 w-1/3 opacity-5 pointer-events-none md:block hidden">
              <Compass size={300} className="text-[#ffc640] absolute -right-16 -bottom-16" />
            </div>

            <div className="flex flex-col lg:flex-row gap-6 lg:items-center justify-between">
              <div className="flex-1 space-y-4">
                <span className="inline-flex items-center gap-2 px-3 py-1 bg-[#ffc640]/15 text-[#ffc640] text-xs font-mono font-bold tracking-widest rounded-full border border-[#ffc640]/30 uppercase">
                  <Workflow size={12} /> Digital Archival Center
                </span>
                <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-[#d8e3fb] tracking-tight leading-tight">
                  Dr. Nitin Mishra | Research Papers Repository
                </h1>
                <p className="font-sans text-sm md:text-base text-[#c6c6cd] max-w-3xl leading-relaxed">
                  Welcome to our digital archive. Our laboratory focuses on high-impact computational research, exploring the intersections of artificial intelligence, distributed systems, and decentralized web structures. This repository hosts our peer-reviewed publications, technical whitepapers, and plain HTML files mapped directly for instant scholastic indexing.
                </p>
                
                <div className="pt-2 flex flex-wrap gap-4 text-xs font-mono text-[#c6c6cd]/90">
                  <span className="flex items-center gap-1">
                    <CheckCircle size={14} className="text-green-400" />
                    W3C Compliant Directory
                  </span>
                  <span>•</span>
                  <span>Principal Investigator: <b>Dr. Nitin Mishra</b></span>
                  <span>•</span>
                  <span>Updated: <b>Real-time</b></span>
                </div>
              </div>

              {/* Institutional Permanence Image representation */}
              <div className="relative w-full lg:w-80 h-44 rounded-xl overflow-hidden shadow-md border border-[#1f2a3c] flex-shrink-0">
                <img 
                  className="w-full h-full object-cover grayscale brightness-90 hover:grayscale-0 transition-all duration-700" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAd1QYcDrDH15fgDDbtd8KSImZcjNjOS_kyKSU35Bdlu2nPQiqzXr4p-V5XEj8zyq9drMgvRpFTgnQlTP3iWc1oJb71IYmgOOA7s5uCA-8jAnXbDrc3owHrmuCypMyV7sn8poMxC3Amb66BKwehovd5sekPT3GOb_b4rVvXKPS4wcSpXFkSNorHYnBnvHgEb46uazki2WP17zgQh9T6kdMfC--4AP83jpmBuKE8zOCDfv93tPXQi1r6G1GU0ZHLGci4iRFntXwW1wdH" 
                  alt="Scholarly Library Archway" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#081425] via-transparent to-transparent opacity-60" />
              </div>
            </div>
          </section>
        )}

        {/* Dynamic Counter Statistics Panels */}
        <StatsGrid totalPagesCount={pages.length} totalCitations={totalCitations} />

        {/* Views Router */}
        {currentView === 'public' ? (
          /* Public Search matrix and sidebar split */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Main column - Papers list */}
            <div className="lg:col-span-8 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="font-serif text-xl font-bold text-[#d8e3fb] flex items-center gap-2">
                  <span className="h-6 w-1 bg-[#ffc640] rounded-full inline-block" />
                  Scholarly publications
                </h2>
                <span className="text-xs text-[#c6c6cd]">
                  Page <b>1</b> of <b>1</b>
                </span>
              </div>

              <PaperList
                pages={pages}
                onInspectPage={setInspectedPage}
                activeCategory={activeCategory}
                setActiveCategory={setActiveCategory}
              />
            </div>

            {/* Right column - Team members & Focus tags */}
            <div className="lg:col-span-4">
              <TeamFocusSidebar
                teamMembers={INITIAL_TEAM_MEMBERS}
                pages={pages}
                activeCategory={activeCategory}
                setActiveCategory={setActiveCategory}
                onPreviewMember={setSelectedMember}
              />
            </div>
          </div>
        ) : (
          /* Administrative index manager & table */
          <div className="space-y-6">
            <div className="border-b border-[#1f2a3c] pb-4 flex justify-between items-center flex-wrap gap-4">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#d8e3fb]">
                  HTML Site & Directory Indexer
                </h2>
                <p className="text-xs text-[#c6c6cd] mt-1">
                  Manage indexed pages pathing, perform relative link checks, audit keywords structures, and write custom metadata tags.
                </p>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 bg-green-950/20 text-green-300 rounded border border-green-900 text-xs">
                <span className="w-2 h-2 rounded-full bg-green-400" />
                Audit engine: Active
              </div>
            </div>

            <SiteManager
              pages={pages}
              onAddPage={handleAddPage}
              onEditPage={handleEditPage}
              onDeletePage={handleDeletePage}
              onInspectPage={setInspectedPage}
              auditReport={auditReport}
              onRunAudit={handleRunAudit}
            />
          </div>
        )}
      </main>

      {/* Global Interactive Page Inspector (HTML pre-renderer and source code) */}
      <PageInspectorModal page={inspectedPage} onClose={() => setInspectedPage(null)} />

      {/* Team Member Profile Preview modal card drawer */}
      {selectedMember && (
        <div className="fixed inset-0 bg-[#040e1f]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111c2d] border border-[#1f2a3c] w-full max-w-md rounded-xl overflow-hidden shadow-2xl animate-scaleUp">
            <div className="bg-[#152031] p-6 text-center border-b border-[#1f2a3c] relative">
              <button 
                onClick={() => setSelectedMember(null)}
                className="absolute right-4 top-4 text-[#c6c6cd] hover:text-[#ffc640] text-sm font-bold font-mono"
              >
                ✕
              </button>
              
              <div className="w-20 h-20 rounded-full overflow-hidden bg-[#0f172a] border-2 border-[#ffc640] mx-auto mb-4">
                <img 
                  className="w-full h-full object-cover" 
                  src={selectedMember.avatar} 
                  alt={selectedMember.name} 
                  referrerPolicy="no-referrer"
                />
              </div>

              <h3 className="font-serif text-lg font-bold text-[#d8e3fb]">{selectedMember.name}</h3>
              <p className="text-xs text-[#ffc640] uppercase font-mono tracking-wider font-semibold mt-1">
                {selectedMember.role}
              </p>
            </div>

            <div className="p-6 space-y-4 text-sm text-[#c6c6cd]">
              <div className="space-y-1">
                <span className="block text-[10px] font-mono text-[#ffc640] uppercase">Sector Biography</span>
                <p className="leading-relaxed font-sans">{selectedMember.bio}</p>
              </div>

              <div className="space-y-1 pt-2 border-t border-[#1f2a3c] flex justify-between items-center text-xs">
                <span className="font-mono text-[#ffc640] uppercase text-[10px]">Staff Coordinate</span>
                <a 
                  href={`mailto:${selectedMember.email}`} 
                  className="flex items-center gap-1 text-[#ffc640] hover:underline"
                >
                  <Mail size={13} />
                  {selectedMember.email}
                </a>
              </div>
            </div>

            <div className="bg-[#152031] p-4 border-t border-[#1f2a3c] flex justify-end">
              <button
                onClick={() => setSelectedMember(null)}
                className="bg-[#0f172a] text-[#c6c6cd] border border-[#1f2a3c] hover:border-[#ffc640]/50 hover:text-[#ffc640] px-4 py-2 rounded text-xs font-semibold"
              >
                Close Biography
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Comprehensive Integrity Scan Modal Screen */}
      {isAuditModalOpen && (
        <div className="fixed inset-0 bg-[#040e1f]/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111c2d] border border-[#1f2a3c] w-full max-w-2xl rounded-xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh] animate-scaleUp">
            
            <div className="bg-[#152031] p-4 border-b border-[#1f2a3c] flex justify-between items-center flex-shrink-0">
              <h3 className="font-serif text-md font-bold text-[#d8e3fb] flex items-center gap-2">
                <ShieldCheck size={18} className="text-[#ffc640]" />
                Interactive Repository Integrity Report
              </h3>
              <button 
                onClick={() => setIsAuditModalOpen(false)}
                className="text-xs text-[#c6c6cd] hover:text-[#ffc640] font-bold font-mono px-2 py-1 bg-[#0f172a] rounded hover:bg-[#1f2a3c]"
              >
                ✕ Close Report
              </button>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto flex-1 text-sm text-[#c6c6cd]">
              {/* Score header */}
              <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-[#0f172a] rounded-xl border border-[#1f2a3c]">
                <div className="w-24 h-24 rounded-full border-4 border-[#ffc640] flex flex-col items-center justify-center bg-[#152031] flex-shrink-0">
                  <span className="text-[10px] font-mono uppercase text-[#c6c6cd]/80 leading-none">Score</span>
                  <span className="text-2xl font-serif font-bold text-[#ffc640] mt-1">
                    {auditReport ? Math.max(0, 100 - (auditReport.brokenLinksCount * 15 + auditReport.duplicatePathsCount * 25 + auditReport.missingMetaCount * 5)) : 100}%
                  </span>
                </div>
                <div className="space-y-1">
                  <h4 className="font-serif text-lg font-bold text-[#d8e3fb]">Clinical Page Directory Audit</h4>
                  <p className="text-xs leading-relaxed text-[#c6c6cd]/90">
                    Your static repository directories are checked against semantic outline targets inside abstracts and page manifest trees.
                  </p>
                  <p className="text-[10px] text-[#c6c6cd]/60 font-mono">
                    Scanned assets: <b>{pages.length} records</b> | Reference citations: <b>{totalCitations} references</b>
                  </p>
                </div>
              </div>

              {/* Status Section Grid breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                <div className="bg-[#152031] p-3 rounded-lg border border-[#1f2a3c]">
                  <div className="text-xs text-[#c6c6cd]/80 font-mono">ACTIVE</div>
                  <div className="text-xl font-bold font-mono text-green-400 mt-1">{activeCount}</div>
                </div>
                <div className="bg-[#152031] p-3 rounded-lg border border-[#1f2a3c]">
                  <div className="text-xs text-[#c6c6cd]/80 font-mono">DRAFTS</div>
                  <div className="text-xl font-bold font-mono text-blue-300 mt-1">{draftCount}</div>
                </div>
                <div className="bg-[#152031] p-3 rounded-lg border border-[#1f2a3c]">
                  <div className="text-xs text-[#c6c6cd]/80 font-mono">REVIEW</div>
                  <div className="text-xl font-bold font-mono text-[#ffc640] mt-1">{needsReviewCount}</div>
                </div>
                <div className="bg-[#152031] p-3 rounded-lg border border-[#1f2a3c]">
                  <div className="text-xs text-[#c6c6cd]/80 font-mono">ORPHANS</div>
                  <div className="text-xl font-bold font-mono text-red-400 mt-1">{orphanedCount}</div>
                </div>
              </div>

              {/* Detailed Lists */}
              <div className="space-y-4">
                <h5 className="font-mono text-xs uppercase text-[#ffc640] tracking-wider border-b border-[#1f2a3c] pb-2">
                  Warnings Logs & Correction suggestions
                </h5>

                {auditReport && (
                  <div className="space-y-3">
                    {/* Broken link list */}
                    {auditReport.brokenLinksCount > 0 ? (
                      <div className="space-y-2">
                        <span className="text-xs font-semibold text-red-400 block font-mono">Broken Internal Paths ({auditReport.brokenLinksCount})</span>
                        {auditReport.brokenLinksList.map((err, i) => (
                          <div key={i} className="bg-red-950/20 border border-red-900/40 p-2.5 rounded text-xs text-red-300">
                            Inside <b>{err.pageTitle}</b>, referenced path <code>{err.path}</code> is unresolvable. Replace the reference path or create a matching template.
                          </div>
                        ))}
                      </div>
                    ) : null}

                    {/* Duplicate paths check */}
                    {auditReport.duplicatePathsCount > 0 ? (
                      <div className="bg-red-950/20 border border-red-900/40 p-3 rounded text-xs text-red-300 space-y-1">
                        <span className="font-bold block font-mono">CRITICAL: Duplicate Paths Target Reserved</span>
                        <p>Several papers claim the exact same target path URI. This prevents clean static indexing compile maps.</p>
                      </div>
                    ) : null}

                    {/* Missing metadata */}
                    {auditReport.missingMetaCount > 0 ? (
                      <div className="space-y-2">
                        <span className="text-xs font-semibold text-[#ffc640] block font-mono">SEO metadata deficiencies ({auditReport.missingMetaCount})</span>
                        {auditReport.missingMetaList.map((warn, i) => (
                          <div key={i} className="bg-orange-950/20 border border-orange-900/30 p-2.5 rounded text-xs text-[#ffc640]">
                            <b>{warn.pageTitle}</b> is missing: {warn.missingFields.join(', ')}. Recommend editing file metadata to optimize scholastic rankings.
                          </div>
                        ))}
                      </div>
                    ) : null}

                    {auditReport.brokenLinksCount === 0 && auditReport.duplicatePathsCount === 0 && auditReport.missingMetaCount === 0 && (
                      <div className="text-center py-6 bg-[#0f172a] rounded-lg border border-green-800/40 text-green-300 text-xs space-y-2 p-4">
                        <div className="text-lg font-bold font-serif">A+ Repository Integrity!</div>
                        <p>All pages checked against broken links references. Key description headers and keywords are fully comprehensive.</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="bg-[#152031] p-4 border-t border-[#1f2a3c] flex justify-between items-center flex-shrink-0 flex-wrap gap-3">
              <span className="text-xs text-[#c6c6cd] flex items-center gap-1">
                <Info size={14} className="text-[#ffc640]" />
                Audit report compiled dynamically inside client sandboxes.
              </span>
              <button
                onClick={() => setIsAuditModalOpen(false)}
                className="bg-[#ffc640] text-[#402d00] hover:bg-[#ffc640]/90 px-4 py-2 rounded-lg text-xs font-semibold"
              >
                Close Audit Interface
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Persistent Footer and terms info */}
      <footer className="w-full py-8 px-4 sm:px-6 lg:px-8 bg-[#040e1f] border-t border-[#1f2a3c] flex flex-col md:flex-row justify-between items-center gap-6 mt-12">
        <div className="flex flex-col gap-1 items-center md:items-start text-center md:text-left">
          <div className="font-serif text-lg text-[#ffc640] font-bold">Mishra Lab Archives</div>
          <p className="font-sans text-xs text-[#c6c6cd]">
            © 2026 Dr. Nitin Mishra Research Lab. All rights reserved. Persistent client storage enabled.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-4 text-xs text-[#c6c6cd]/90">
          <a href="#" className="hover:text-[#ffc640] transition-colors">Institutional Access</a>
          <span>•</span>
          <a href="#" className="hover:text-[#ffc640] transition-colors">Contact PI</a>
          <span>•</span>
          <a href="#" className="hover:text-[#ffc640] transition-colors">Privacy Statement</a>
          <span>•</span>
          <a href="#" className="hover:text-[#ffc640] transition-colors">Digital Manifest Schema</a>
        </div>
      </footer>

    </div>
  );
}
