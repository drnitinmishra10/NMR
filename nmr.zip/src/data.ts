/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HTMLPage, TeamMember, FocusArea } from './types';

export const INITIAL_TEAM_MEMBERS: TeamMember[] = [
  {
    name: "Dr. Nitin Mishra",
    role: "Principal Investigator",
    avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuBTTdseI5uch_ladXZkFurVwLm5W0zv6zi8LC898pvSa_wN5eEaZkSEAVmDoa8K3VGGO8q-tyWzpNGOAiaOJS4xsHs6uqKvkaTo2aKP3YDcpepiKyVSsxqTsXA-bhcvBT9s1hWRM1XrWqFmG4QBZyt9wzmVmHiDktsthDVA3d0CIuZ1GAgr7fb2NfYZ0Ee2GX90BgM6KkcUawk1_D2SMUFY47Ibg9IkmcwXsxg7LO94ACvNnNHI8mi-LO7G1wMwGwcrB6G1qQDtsrRE",
    bio: "Professor of Computer Science specializing in Distributed Systems, Decentralized Consensus algorithms, and Trusted Execution Environments.",
    email: "nitin.mishra@mishralab.edu"
  },
  {
    name: "Dr. Sarah Chen",
    role: "Senior Associate",
    avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuCxAKRJgyWEyZ30KuX4oELm3_MxkcfcVJZJzx7MQOuHidtmGXU0OOTB9YBrCPjliifCtjLi10mKA-FHDFD0tbrEiQXLNtOLukB3qGP2nQ2hYYKX-O-p7bWe_3YyIY4Xbuzl6eg20aFy0cO58dLYBS18hj5RhbUOX2UskMs9Aod1MfTuKVKpCHqHhjEP6eGdzMlXO3bNgzcr3GFhMeVFUkJeOyZUdCGeESHYknVmmzVfz0XBcmR01vCaN1akaqcXSUpeSsCHe7a6AKGG",
    bio: "Postdoctoral Researcher focusing on AI Ethics, natural language bias audits, and algorithmic fairness.",
    email: "sarah.chen@mishralab.edu"
  },
  {
    name: "Marcus Thorne",
    role: "Ph.D. Candidate",
    avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuAz8vzUm-FIJCRN1jQ7QL3NbPp8qwXO16PoCve2b0CYpeibj_ZWSXOVnHjbR8MJZqR6zfjYcY9OtCr6uUs46bLSC5RuzCNXOPrtET-ZQsutwMOZUwxlgMS6Uf7RIaHvjZxGgl7l0NciWbdUfQfuCJuQhKCBDDj3Q48VBk4gapy2vxYRVCYQWYlKE9Aa_6hXy7flQl0Rl2jRpLa-hhwhOIPrJoyIuz8p4P8i7tanflaPDgPMleT4ydeEcwiqaUVsR1iw9x1yUKnRiYPT",
    bio: "Ph.D. student researching IoT edge device security, zero-trust protocols, and cryptographic micro-kernels.",
    email: "m.thorne@mishralab.edu"
  }
];

export const INITIAL_FOCUS_AREAS: FocusArea[] = [
  { name: "Distributed Systems", count: 14 },
  { name: "Machine Learning", count: 28 },
  { name: "IoT Security", count: 9 },
  { name: "AI Ethics", count: 15 }
];

export const INITIAL_PAGES: HTMLPage[] = [
  {
    id: "page-1",
    title: "Scalable Consensus Protocols in Low-Latency Heterogeneous Networks",
    author: "Dr. Nitin Mishra",
    date: "2024-04-12",
    year: 2024,
    category: "Distributed Systems",
    excerpt: "This paper presents a novel approach to achieving consensus in large-scale distributed environments where nodes exhibit significantly different computational capabilities and network latencies. We propose a weighted leader-election mechanism that optimizes throughput and minimizes communication overhead.",
    citations: 54,
    filePath: "/papers/distributed-systems/scalable-consensus-2024.html",
    status: "Active",
    fileSize: "42.5 KB",
    lastModified: "2024-04-12T10:30:00Z",
    metaDescription: "A comprehensive guide to designing low-latency consensus protocols in federated, heterogeneous networks.",
    metaKeywords: ["Distributed Systems", "Consensus", "Fault Tolerance", "Low-Latency"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Scalable Consensus Protocols in Low-Latency Heterogeneous Networks</title>
</head>
<body>
  <h1>Scalable Consensus Protocols in Low-Latency Heterogeneous Networks</h1>
  <p><strong>Author:</strong> Dr. Nitin Mishra</p>
  <p><strong>Published:</strong> April 2024</p>
  <hr>
  <h2>Abstract</h2>
  <p>This paper presents a novel approach to achieving consensus in large-scale distributed environments...</p>
</body>
</html>`
  },
  {
    id: "page-2",
    title: "Auditing Bias in Automated Grading Systems for Large-Scale Online Education",
    author: "Dr. Sarah Chen, Dr. Nitin Mishra",
    date: "2023-11-05",
    year: 2023,
    category: "AI Ethics",
    excerpt: "As automated grading becomes ubiquitous in MOOCs, ensuring algorithmic fairness is critical. We analyze three major grading frameworks and identify systemic biases in natural language processing models used for essay evaluation, presenting correction protocols.",
    citations: 112,
    filePath: "/papers/ai-ethics/automated-grading-bias-2023.html",
    status: "Active",
    fileSize: "28.1 KB",
    lastModified: "2023-11-05T14:45:00Z",
    metaDescription: "Audity of biases present in automated grading frameworks on massive open online courses.",
    metaKeywords: ["AI Ethics", "Natural Language Processing", "MOOCs", "Bias Detection"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Auditing Bias in Automated Grading Systems for Large-Scale Online Education</title>
</head>
<body>
  <h1>Auditing Bias in Automated Grading Systems</h1>
  <p><strong>Authors:</strong> Dr. Sarah Chen, Dr. Nitin Mishra</p>
</body>
</html>`
  },
  {
    id: "page-3",
    title: "Zero-Trust Architectures for Edge Computing in Industrial IoT",
    author: "Marcus Thorne, Dr. Nitin Mishra",
    date: "2023-08-19",
    year: 2023,
    category: "IoT Security",
    excerpt: "Industrial IoT environments present unique security challenges due to the proximity of physical sensors and actuators. This research explores the implementation of zero-trust security models specifically designed for low-power edge nodes with lightweight cryptographic signatures.",
    citations: 89,
    filePath: "/papers/iot/zero-trust-edge-2023.html",
    status: "Active",
    fileSize: "37.8 KB",
    lastModified: "2023-08-19T09:15:00Z",
    metaDescription: "Implementing zero-trust templates for resource-constrained IoT equipment and edge setups.",
    metaKeywords: ["IoT Security", "Zero-Trust", "Edge Computing", "Cryptography"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Zero-Trust Architectures for Edge Computing in Industrial IoT</title>
</head>
<body>
  <h1>Zero-Trust Architectures for Edge Computing</h1>
  <p><strong>Authors:</strong> Marcus Thorne, Dr. Nitin Mishra</p>
</body>
</html>`
  },
  {
    id: "page-4",
    title: "Federated Learning for Decentralized Clinical Trial Analysis",
    author: "Dr. Sarah Chen",
    date: "2024-02-10",
    year: 2024,
    category: "Machine Learning",
    excerpt: "Clinical trials often suffer from restricted data silos due to strict privacy regulations. This paper evaluates the effectiveness of secure multi-party computation coupled with federated learning architectures to safely aggregate patient clinical signals.",
    citations: 34,
    filePath: "/papers/machine-learning/federated-clinical-trials.html",
    status: "Draft",
    fileSize: "55.4 KB",
    lastModified: "2024-02-10T11:00:00Z",
    metaDescription: "Secure multi-party aggregation and federated learning on private clinical trials datasets.",
    metaKeywords: ["Federated Learning", "Clinical Trials", "Privacy Preserving IP"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Federated Learning for Decentralized Clinical Trial Analysis</title>
</head>
<body>
  <h1>Federated Learning for Decentralized Clinical Trial Analysis</h1>
</body>
</html>`
  },
  {
    id: "page-5",
    title: "Evaluating Byzantine Fault Tolerance in High-Frequency FinTech Registers",
    author: "Dr. Nitin Mishra",
    date: "2022-09-30",
    year: 2022,
    category: "Distributed Systems",
    excerpt: "Financial databases require ultra-fast throughput with strict finality. This work benchmarks four distinct Byzantine fault-tolerant protocols under high transactions-per-second loads, diagnosing bottlenecks inside message replication loops.",
    citations: 78,
    filePath: "/papers/distributed-systems/byzantine-fintech-2022.html",
    status: "Active",
    fileSize: "19.2 KB",
    lastModified: "2022-09-30T17:20:00Z",
    metaDescription: "A systematic evaluation of classical BFT algorithms adapted for modern sub-millisecond fintech registries.",
    metaKeywords: ["Byzantine", "BFT", "FinTech", "High Frequency"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <title>Evaluating Byzantine Fault Tolerance in FinTech Registers</title>
</head>
<body>
  <h1>Evaluating Byzantine Fault Tolerance</h1>
</body>
</html>`
  },
  {
    id: "page-6",
    title: "A Lightweight Secure Encapsulation Protocol for Agricultural Smart Sensors",
    author: "Marcus Thorne, Dr. Nitin Mishra",
    date: "2023-01-15",
    year: 2023,
    category: "IoT Security",
    excerpt: "Agricultural sensor arrays are frequently deployed in unsecured wilderness zones, exposed to physical and wireless attacks. We present a custom cryptographic handshake and physical encap-auth state machine running on 8-bit microcontrollers.",
    citations: 45,
    filePath: "/papers/iot/agri-smart-sensors-secure.html",
    status: "Needs Review",
    fileSize: "14.2 KB",
    lastModified: "2023-01-15T08:00:00Z",
    metaDescription: "Extremely lightweight encryption protocol designed for remote agricultural deployments without power backups.",
    metaKeywords: ["IoT", "Microcontrollers", "Agricultural Technology", "Sensors"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <title>A Lightweight Secure Encapsulation Protocol for Agricultural Smart Sensors</title>
</head>
<body>
  <h1>Encapsulation Protocol for Agricultural Sensors</h1>
</body>
</html>`
  },
  {
    id: "page-7",
    title: "A Survey of LLM Jailbreaking Mitigations and Safety Alignments",
    author: "Dr. Sarah Chen",
    date: "2024-05-18",
    year: 2024,
    category: "AI Ethics",
    excerpt: "As state-of-the-art Large Language Models are integrated into automated customer workflows, prompt-injection countermeasures become critical. We classify and compare current adversarial detection, context sanitization, and output filter methods.",
    citations: 18,
    filePath: "/papers/ai-ethics/llm-jailbreaking-mitigations-2024.html",
    status: "Active",
    fileSize: "61.3 KB",
    lastModified: "2024-05-18T16:40:00Z",
    metaDescription: "An in-depth map of jailbreaking defense patterns and safety alignment strategies for generative models.",
    metaKeywords: ["AI Safety", "Jailbreaking Defenses", "Generative AI", "Auditing"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <title>A Survey of LLM Jailbreaking Mitigations and Safety Alignments</title>
</head>
<body>
  <h1>A Survey of LLM Jailbreaking Mitigations</h1>
</body>
</html>`
  },
  {
    id: "page-8",
    title: "Optimized Gradient Vector Estimation for Edge Node Neural Enclaves",
    author: "Dr. Nitin Mishra, Dr. Sarah Chen",
    date: "2023-05-02",
    year: 2023,
    category: "Machine Learning",
    excerpt: "This research addresses the intensive network burdens of standard deep learning gradient sharing on mobile chips. We introduce an adaptive sparse pooling algorithm that halves payload sizes while maintaining a 98.4% classifier accuracy limit.",
    citations: 56,
    filePath: "/papers/machine-learning/optimized-gradient-vector-edge-2023.html",
    status: "Active",
    fileSize: "33.0 KB",
    lastModified: "2023-05-02T12:10:00Z",
    metaDescription: "A sparse compression approach for AI weights sharing directly over sparse edge installations.",
    metaKeywords: ["Neural Networks", "Edge Computing", "Gradient Sparsification", "Optimization"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <title>Optimized Gradient Vector Estimation</title>
</head>
<body>
  <h1>Optimized Gradient Vector Estimation</h1>
</body>
</html>`
  },
  {
    id: "page-9",
    title: "Privacy Audit of Interactive Dynamic Map Interfaces on Local Council Portals",
    author: "Dr. Sarah Chen",
    date: "2022-12-10",
    year: 2022,
    category: "AI Ethics",
    excerpt: "This archival page documents privacy issues on local council mapping portals. Interactive maps frequently leak GPS parameters, session cookies, and geographic search intent to unauthorized advertising syndicates through unmonitored scripts.",
    citations: 12,
    filePath: "/papers/archives/privacy-audit-local-maps-outdated-draft.html", // Notice the path for search
    status: "Orphaned",
    fileSize: "8.9 KB",
    lastModified: "2022-12-10T15:30:00Z",
    metaDescription: "Investigating location leakages in legacy municipal mapping embeds using automated audits.",
    metaKeywords: ["Privacy Audit", "Mapping Portals", "Advertising Cookies", "Local Government"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <title>Outdated Mapping Privacy Draft</title>
</head>
<body>
  <h1>Outdated Municipal Maps Audit</h1>
  <p>Warning: This file is orphaned (unlinked from core indexes) but kept for historical research purposes.</p>
</body>
</html>`
  },
  {
    id: "page-10",
    title: "Static File Indexes and Manifest Structuring inside Large Scholarly Repositories",
    author: "Dr. Nitin Mishra",
    date: "2024-03-25",
    year: 2024,
    category: "Distributed Systems",
    excerpt: "This paper acts as the technical manual for the Mishra Lab directory site structure. We model optimal indexing architectures, caching, searching, and structural auditing tools to maintain extensive static HTML publication lists.",
    citations: 5,
    filePath: "/papers/distributed-systems/site-indexer-architecture.html",
    status: "Active",
    fileSize: "12.4 KB",
    lastModified: "2024-03-25T11:00:00Z",
    metaDescription: "Systematic indexer blueprint for managing extensive academic sites containing multiple plain HTML pages.",
    metaKeywords: ["Indexing", "Site Management", "HTML Indexes", "Site Architecture"],
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <title>Static File Indexes and Manifest Structuring</title>
</head>
<body>
  <h1>Static File Indexes and Manifest Structuring</h1>
  <p>Technical guidance on how to audit, manage, and searchable-index 66+ scholarly records.</p>
</body>
</html>`
  }
];
